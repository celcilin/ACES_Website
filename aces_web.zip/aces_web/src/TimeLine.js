import React from 'react';
import './TimeLine.css';

const StoryOfAces = () => {
  return (
    <div className="container1">
      <h1>The Story Of <span>ACES</span></h1>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit semper dolor 
        elementum tempus hac tellus libero accumsan.
      </p>
      <div className="timeline">
        <div className="timeline-item">
          <span className="year">2020</span>
          <span className="event"></span>
        </div>
        <div className="timeline-item">
          <span className="year">2021</span>
          <span className="event"></span>
        </div>
        <div className="timeline-item">
          <span className="year">2022</span>
          <span className="event"></span>
        </div>
        {/* Add more timeline items as needed */}
      </div>
    </div>
  );
};

export default StoryOfAces;
