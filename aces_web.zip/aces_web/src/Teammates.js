import React  from 'react'
import './teammates.css'; 

function TeamCard(params) {
    return(

        <section className="team-section">
        <h2>Meet Our Core Team</h2>
        <div className="team-container">
          <div className="team-member">
            <img src="john.jpg" alt="John Carter" className="member-photo" />
            <h3>John Carter</h3>
            <p className="member-position">CEO & Co-Founder</p>
            <p className="member-description">Lorem ipsum dolor sit amet consectetur adipiscing elit amet hendrerit.</p>
            <div className="social-icons">
              <a href="/"><i className="fab fa-facebook-f"></i></a>
              <a href="/"><i className="fab fa-twitter"></i></a>
              <a href="/"><i className="fab fa-linkedin-in"></i></a>
              <a href="/"><i className="fab fa-instagram"></i></a>
            </div>
          </div>
          <div className="team-member">
            <img src="sophie.jpg" alt="Sophie Moore" className="member-photo" />
            <h3>Sophie Moore</h3>
            <p className="member-position">CTO & Co-Founder</p>
            <p className="member-description">Lorem ipsum dolor sit amet consectetur adipiscing elit amet hendrerit.</p>
            <div className="social-icons">
              <a href="/"><i className="fab fa-facebook-f"></i></a>
              <a href="/"><i className="fab fa-twitter"></i></a>
              <a href="/"><i className="fab fa-linkedin-in"></i></a>
              <a href="/"><i className="fab fa-instagram"></i></a>
            </div>
          </div>
          <div className="team-member">
            <img src="matt.jpg" alt="Matt Cannon" className="member-photo" />
            <h3>Matt Cannon</h3>
            <p className="member-position">VP of Marketing</p>
            <p className="member-description">Lorem ipsum dolor sit amet consectetur adipiscing elit amet hendrerit.</p>
            <div className="social-icons">
              <a href="/"><i className="fab fa-facebook-f"></i></a>
              <a href="/"><i className="fab fa-twitter"></i></a>
              <a href="/"><i className="fab fa-linkedin-in"></i></a>
              <a href="/"><i className="fab fa-instagram"></i></a>
            </div>
          </div>
        </div>
       
      </section>

    );
    
}

export default TeamCard;