import React from 'react'
import './events.css'; // Import the CSS file
import img from './scr.jpg'; // Import the image file


function EventNews(params) {

    return(

        
        <div className="second">


    <div className="event-card">
        <div className="event-image">
            <img src={img} alt="Event"/>
        </div>
        <div className="event-details">
            <div><h2>Handover Ceremony</h2></div>
            Status: Upcoming   
                <br/>
                Date: 30-07-2024 | Tuesday
           
        </div>
        <button className="join-button">Join Now</button>

    </div>
</div>


    );
}
export default EventNews;
