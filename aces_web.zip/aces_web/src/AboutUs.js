import React from 'react'
import './Aboutus.css';  
import im from './team.jpg';

const AboutUs = () => {
  return (
    
      <div className="container4">
        <div className="image-container">
            <img src={im} alt="Teamwork Illustration" />
        </div>
        <div className="text-container">
            <h2>About ACES</h2>
            <p>
                By creating a visual guide along the way, the designer or developer can get input from the other people 
                involved in the website such as the customer, their manager, and other members of the team.
            </p>
            <div className="points">
                <div className="point">
                    <h3>No. 1</h3>
                    <p>The effect of different scenarios on the display</p>
                </div>
                <div className="point">
                    <h3>No. 2</h3>
                    <p>The range of functions available</p>
                </div>
            </div>
        </div>
    </div>
   
  )
}

export default AboutUs
