import NavBar from './Nav';
import EventNews from './Events';
import './App.css';
import News from './NewsLetter';
import Foot from './Footer';
import TeamCard from './Teammates';
import ContactForm from './Contact';
import AboutUs from './AboutUs';
import TimeLine from './TimeLine';
 
function App() {
  return (
    <>
  
    <NavBar  />
    <EventNews/> 
    <TeamCard/>
    <News/>
    <AboutUs/>
    <TimeLine/>
    <ContactForm/>
    <Foot/>

</>
  );
}

export default App;
