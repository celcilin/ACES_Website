import React from 'react';
import './Contact.css';

const ContactForm = () => {
  return (
    <div className="container2">
     <div className="pad">
     <div className="form-container">
        <h2>Get in touch today</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit nulla adipisicing incididunt interdum tellus du.</p>
        <form action="#" method="post">
          <input type="text" name="name" placeholder="Name" required />
          <input type="email" name="email" placeholder="Email" required />
          <textarea name="message" placeholder="Please type your message here..." rows="4" required></textarea>
          <input type="submit" value="Send message" />
        </form>
      </div>
      </div> 
      <div className="image-container">
        <img src="contact-image.png" alt="Contact Us Illustration" />
      </div>
    </div>
  );
};

export default ContactForm;
