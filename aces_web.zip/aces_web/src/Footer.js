import React from 'react';
import './Footer.css';  
import logo from './logo.png';  


function Foot() {
  return (
    <footer className="footer">
      <div className="instagram-section">
        <h3>Follow us on <span>Instagram</span></h3>
        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit semper dolor elementum tempus hac felis libero accumsan.</p>
        <div className="instagram-images">
          <img src="/images/image1.jpg" alt="Event 1" />
          <img src="/images/image2.jpg" alt="Event 2" />
          <img src="/images/image3.jpg" alt="Event 3" />
          <img src="/images/image4.jpg" alt="Event 4" />
          <img src="/images/image5.jpg" alt="Event 5" />
          <img src="/images/image6.jpg" alt="Event 6" />
        </div>
      </div>
      <div className="footer-nav">
        <img src={logo} alt="Logo" className="footer-logo" />
        <ul className="footer-links">
          <li><a href="/">Home</a></li>
          <li><a href="/">About</a></li>
          <li><a href="/">Pricing</a></li>
          <li><a href="/">Blog</a></li>
          <li><a href="/">Contact</a></li>
        </ul>
        <div className="social-media-icons">
          <a href="/"><i className="fab fa-facebook-f"></i></a>
          <a href="/"><i className="fab fa-twitter"></i></a>
          <a href="/"><i className="fab fa-linkedin-in"></i></a>
          <a href="/"><i className="fab fa-instagram"></i></a>
        </div>
      </div>
      <div className="footer-bottom">
        <p>Copyright &copy; 2024 Team Aces | All Rights Reserved</p>
      </div>
    </footer>
  );
}

export default Foot;
